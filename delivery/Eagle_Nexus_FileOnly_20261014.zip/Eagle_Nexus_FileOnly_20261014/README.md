# Eagle Nexus — Windows File-Only Transfer Bundle (2026-10-14)

This is a **data-only** ZIP assembled from two public repositories at the exact pinned commits recorded in runtime_manifest.json. It includes 11 unmodified runtime files, their SHA-256 checksums, and no executable installer. The upstream OAIAPI MIT LICENSE is included.

**DO NOT extract directly into a running ComfyUI or execute a package installer automatically.** Extract into a fresh staging folder outside ComfyUI. Before any placement, obtain separate approval, verify the exact Windows ComfyUI process/root/interpreter and both queue states, confirm all node search paths have no conflicting enabled/disabled packages, and verify each payload file against CHECKSUMS.sha256. Use the already-tested private file-only deployment tool and its approval/queue safeguards for any eventual placement.

Payload directories under custom_nodes/:
- nexus_impact_binding — NexusImpactPrepare and NexusImpactBind (expected outputs: 4 / 12).
- comfyui-openai-api — OAIAPI_Client and OAIAPI_ChatCompletion.

**Dependencies:** Do not run pip, requirements.txt, pyproject installation, ComfyUI Manager install, or update-all. Original OAIAPI metadata declares openai>=2.7.1; original requirements.txt says openai with no upper cap. The existing Windows SDK 1.109.1 passed isolated compatibility testing but has not been proven to import on the target Windows system. An explicitly approved file-only install does not process dependency metadata.

**Important boundaries:** File placement, ComfyUI-only restart, and C09 GPU/VLM requests each need separate consent. No installation, restart, GPU request, VLM request, cloud image upload, or modification of main/READY/Production is performed by this ZIP. Do not use the public cloud OAIAPI default endpoint. After an independently approved restart, use Artokun MCP /object_info to check the four required classes and port schema. Stop on any mismatch.

Keep the original pinned source commits; this delivery archive does not replace either original package or change their published contents.
